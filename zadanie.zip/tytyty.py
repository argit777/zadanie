from flask import Flask, url_for, request

app = Flask(__name__)


@app.route('/')
def image():
    return f"""<!doctype html>
                <html lang="en">
                  <head>
                    <meta charset="utf-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
                    <link rel="stylesheet" 
                    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" 
                    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" 
                    crossorigin="anonymous">
                    <link rel="stylesheet" href="style.css">
                    <title>Пейзажи Марса</title>
                  </head>
                  <body>
                  <center><h1>Пейзажи Марса</h1></center>
                  <div id="Zadanie" class="carousel slide" data-ride="carousel">
                      <ol class="carousel-indicators">
                          <li data-target="#Zadanie" data-slide-to="0" class="active"></li>
                          <li data-target="#Zadanie" data-slide-to="1"></li>
                          <li data-target="#Zadanie" data-slide-to="2"></li>
                      </ol>
                     <div class="carousel-inner">
                         <div class="carousel-item active">
                             <center><img class="d-block w-50" src="{url_for('static', filename='img/mars1.jpg')}" 
                             alt="здесь должна была быть картинка, но не нашлась"></center>
                         </div>
                         <div class="carousel-item">
                              <center><img class="d-block w-50" src="{url_for('static', filename='img/mars2.jpg')}" 
                              alt="здесь должна была быть картинка, но не нашлась">/<center>
                         </div>
                         <div class="carousel-item">
                             <center><img class="d-block w-50" src="{url_for('static', filename='img/mars3.jpg')}" 
                             alt="здесь должна была быть картинка, но не нашлась"></center>
                         </div>
                     </div>
                  </div>
                  </body>
                </html>"""


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')